import pandas as pd
import matplotlib.pyplot as plt

# Read the sentiment results file
df = pd.read_csv("sentiment_results.csv")

# Count positive, negative, neutral reviews
counts = df["Sentiment"].value_counts()

# Create bar chart
counts.plot(kind="bar")

plt.title("Sentiment Count")
plt.xlabel("Sentiment")
plt.ylabel("Count")

plt.show()