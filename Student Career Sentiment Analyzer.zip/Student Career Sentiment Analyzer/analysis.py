from textblob import TextBlob
import pandas as pd

df = pd.read_csv("student_reviews.csv")

def sentiment(text):

    score = TextBlob(text).sentiment.polarity

    if score > 0:
        return "Positive"

    elif score < 0:
        return "Negative"

    else:
        return "Neutral"

df["Sentiment"] = df["review"].apply(sentiment)

print(df)

df.to_csv(
    "sentiment_results.csv",
    index=False
)