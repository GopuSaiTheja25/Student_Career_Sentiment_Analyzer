import pandas as pd

df = pd.read_csv("sentiment_results.csv")

print(df["Sentiment"].value_counts())