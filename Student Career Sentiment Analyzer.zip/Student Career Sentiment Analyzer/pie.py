import pandas as pd
import matplotlib.pyplot as plt

# Load the CSV file
df = pd.read_csv("sentiment_results.csv")

# Count sentiments
counts = df["Sentiment"].value_counts()

# Create pie chart
plt.figure(figsize=(7,7))

counts.plot(
    kind="pie",
    autopct="%1.1f%%"
)

plt.title("Student Sentiment Distribution")
plt.ylabel("")

plt.show()