import pandas as pd
from wordcloud import WordCloud
import matplotlib.pyplot as plt

df = pd.read_csv("student_reviews.csv")

text = " ".join(df["review"])

wordcloud = WordCloud(
    width=800,
    height=400
).generate(text)

plt.figure(figsize=(10,5))
plt.imshow(wordcloud)
plt.axis("off")
plt.title("Student Review Word Cloud")
plt.show()